import torch
from torch.utils.data import DataLoader
from LYTNetV2 import LYTNetV2
import matplotlib.pyplot as plt
import numpy as np
from PIL import ImageFile, Image, ImageDraw
from torchvision.transforms import functional as F
from torchvision.transforms import CenterCrop as CC

cuda_available = torch.cuda.is_available()

#image_directory = '/content/drive/MyDrive/ImVisible-master/Trial/0_4.jpg'
#MODEL_PATH = '/content/drive/MyDrive/ImVisible-master/ImVisible-master/Model/LytNetV2_weights'
#image_directory = '~/prj/rpi-trial/Trial/heon_IMG_0518.JPG'
image_directory = '/home/pi/prj/rpi-trial/Trial/heon_IMG_0759.JPG'
MODEL_PATH = '/home/pi/prj/rpi-trial/LytNetV2_weights'
'''
0-> A red walking man
1-> A green walking man
2-> A green walking man and a counter simultaneously
3-> Countdown same as NYC
4-> No signals at all
Results:
0_1 -> 3 blunder
0_2 -> 0 correct
0_3 -> 3 blunder (was blurry)
0_4 -> 0 correct
1_1 -> 1 correct
1_2 -> 3 technically correct but not good
1_3 -> 3 technically correct but not good
3_1 -> 2 also acceptable
3_2 -> 2 also acceptable
Note: Still classifies it's own images very well. Could use that for the live demo if required
'''
#dataset = TrafficLightDataset(csv_file = test_file_loc, img_dir = test_image_directory)
#dataloader = DataLoader(dataset, batch_size=1, shuffle=False, num_workers=2)

net = LYTNetV2()
checkpoint = torch.load(MODEL_PATH, map_location=torch.device('cpu'))
net.load_state_dict(checkpoint)
net.eval()

def my_classifier(inp_img):
    with torch.no_grad():
      image = inp_img #Image.open(image_directory)
      #image = CC((768,576))(image)
      image = image.resize((768,576))
      image = np.transpose(image, (2, 0, 1))
      image = np.expand_dims(image, axis=0)
      image = torch.from_numpy(image)
      image = image.type(torch.FloatTensor)
      #if cuda_available:
      #    image = image.cuda()  
      pred_classes, pred_direc = net(image)
      _, predicted = torch.max(pred_classes, 1)
      print('Class: ',predicted)
      return predicted
    ''''
with torch.no_grad():
  image = Image.open(image_directory)
  #image = CC((768,576))(image)
  image = image.resize((768,576))
  image = np.transpose(image, (2, 0, 1))
  image = np.expand_dims(image, axis=0)
  image = torch.from_numpy(image)
  image = image.type(torch.FloatTensor)
  #if cuda_available:
  #    image = image.cuda()  
  pred_classes, pred_direc = net(image)
  _, predicted = torch.max(pred_classes, 1)

print('Class: ',predicted)
'''

