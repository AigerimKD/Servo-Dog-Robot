import RPi.GPIO as GPIO
import time
from gpiozero import Motor, DistanceSensor, PWMOutputDevice, DigitalOutputDevice
from time import sleep
import VL53L0X
import picamera
import io
from PIL import Image
import socket
import select
from Per_image import my_classifier

from num2words import num2words
from subprocess import call


cmd_beg= 'espeak '

text = 'initializing'


'''
Possible values of CURRENT_STATE:
    -1: Booted, waiting for stuff?

    1: start moving
        a. start moving forward
        b. if ultrasonic < thresh then turn right?
        c. if tof > thresh then move back, turn, move fwd
        d. stop image inference?

    2: stop moving
        a. do nothing, wait for voice commands
        b. run iamge inference

    3: cross
        a. get camera image?
        b. infer image
'''

## States the bot can be in
IDLE = -1
MOVING = 1
STOP = 2
CROSS = 3

CURRENT_STATE = IDLE

us_upper_threshold = 300

tof_threshold = 999999999999

angle_time = 0.1
orientation = 0

classes = {
        0: 'Stop',
        1: 'Go',
        2: 'countdown',
        3: 'countdown',
        4: 'none'
        }

## Dict of voice cmds
VOICE_COMMANDS = {  'start moving':   MOVING, 
                    'stop moving':    STOP,
                    'cross the street':          CROSS,
                    }

## TOF init
tof = VL53L0X.VL53L0X(i2c_bus=1, i2c_address=0x29)
tof.open()
tof.start_ranging(VL53L0X.Vl53l0xAccuracyMode.BETTER)

## Ultrasonic init
ultrasonic = DistanceSensor(echo = 20, trigger = 21)

## Motor init
lmotor = Motor(26, 19, 12)
rmotor = Motor(17, 18, 16)

'''
## TOF sensor functions, get_tof returns value in mm
## REFERENCE: Pimorini website
'''
def get_tof_value():
    timing = tof.get_timing()
    if timing < 20000:
        timing = 20000
    #print("Timing %d ms" % (timing/1000))
    avg_times = 3
    distance_sum = 0
    for count in range(0, avg_times):
        distance = tof.get_distance()
        if distance > 0:
           distance_sum += distance
    time.sleep(timing/1000000.00)

    distance = distance_sum / avg_times
    #print("%d mm, %d cm, %d" % (distance, (distance/10), count))
    return distance 

def close_tof():
    tof.stop_ranging()
    tof.close()
   

'''
## Ultrasonic helper function, returns distance in mm
'''   
def get_ultrasonic_value():
    return ultrasonic.distance * 1000

'''
## Camera capture function, returns PIL image
## REFERENCE: https://picamera.readthedocs.io/en/release-1.10/recipes1.html#capturing-to-a-pil-image
'''
def capture_image():
    stream = io.BytesIO()
    with picamera.PiCamera() as camera:
        camera.capture(stream, format = 'jpeg')
    stream.seek(0)
    image = Image.open(stream)
    return image

'''
## Motor Driver Functions 
'''
def drive_stop():
    lmotor.stop()
    rmotor.stop()
    dbg_print("INFO: MOTOR: Stop")


def drive_forward():
    lmotor.forward()
    rmotor.forward()
    dbg_print("INFO: MOTOR: drive_forward")

def drive_backward():
    lmotor.backward()
    rmotor.backward()
    dbg_print("INFO: MOTOR: drive_backward")

def drive_right():
    lmotor.forward()
    rmotor.backward()
    dbg_print("INFO: MOTOR: drive_right")

def drive_left():
    lmotor.backward()
    rmotor.forward()
    dbg_print("INFO: MOTOR: drive_left")


'''
## Socket init function, can just be moved to main now
'''
def init_socket():
    s = socket.socket()
    port = 8008
    s.bind(('',port))
    s.listen(5)
    print ("INFO: Created Socket")
    return s

def set_tof_threshold():
    global tof_threshold
    tof_threshold = get_tof_value() + 20


def dbg_print(inp):
    print(inp)

def video_class():
    class_val_list = []
    for i in range(3):
        img = capture_image()
        #img = Image.open('/home/pi/prj/rpi-trial/Trial/sam_IMG_4265.jpg')
        fname = str(time.time()) + '.jpg' 
        im1 = img.save(fname)
        class_val_list.append(my_classifier(img))
    op_class = max(set(class_val_list), key = class_val_list.count)

    dbg_print(op_class)

    if ((op_class == 4) or (op_class == 0)):
        time.sleep(2)
        video_class()
    return op_class

if __name__ == '__main__':
    ## TOF call and close
    ## Value in mm
    '''
    print (get_tof_value())
    close_tof()
    '''
    ## Camera capture: returns a PIL type image
    '''
    img = capture_image()
    img = img.save("text-img.jpg")
    '''
    ## Read Ultrasonic-fwd
    ## Value in mm
    '''
    for i in range(30):
        print(get_ultrasonic_value())
        time.sleep(0.2)
    '''
    '''
    voice commands 
    
    '''
    
    sck_data = -1 
    s = init_socket()
    while True:
        try:
            r, w, err = select.select((s,),(),(),1)
            if r:
                for readable in r:
                    client, client_addr = s.accept()
                    try:
                        sck_data = client.recv(128).decode().strip()
                    except OSError as e:
                        pass
            ## Got socket data; sck_data is set to something other than -1
            if (sck_data!=-1):
                print (sck_data)
                if (sck_data.lower() in VOICE_COMMANDS):
                    print ("INFO: Found cmd: {0}".format(sck_data)) 
                    CURRENT_STATE = VOICE_COMMANDS[sck_data]
                    client.send("ACK".encode())
                    client.close()
                else:
                    print ("ERROR: Voice cmd not found")
                    CURRENT_STATE = IDLE
                    client.send("NACK".encode())
                    client.close()
                sck_data = -1
        except Exception as e:
            print(e)
            client.close()
        


        if (CURRENT_STATE == IDLE):
            drive_stop()
            set_tof_threshold()
            orientation = 0

        if (CURRENT_STATE == MOVING):
            tof_val = get_tof_value()
            us_val = get_ultrasonic_value()

            if ( tof_val < tof_threshold ): 
                drive_forward()

            elif ( (tof_val > tof_threshold) and (orientation == 0)): 
                drive_stop()

            else:
                if orientation > 0:
                    drive_right()
                    orientation -= 30
                else:
                    drive_left()
                    orientation += 30
                time.sleep(angle_time)
                drive_stop()

            if (us_val < us_upper_threshold):
                if orientation > 0:
                    drive_right()
                    orientation -= 30
                else:
                    drive_left()
                    orientation += 30
                time.sleep(angle_time)

        if (CURRENT_STATE == CROSS):
            drive_stop()
            determined_class = video_class()
            if determined_class == 0:
                drive_stop()
            else:
                drive_forward()
            dbg_print("INFO: Determined class: ")
            dbg_print(determined_class)
            #drive_forward()
                
        ## Main logic of stuff to be done in the while (1) loop
    '''
        tof_value = get_tof_value()
        us_value = get_ultrasonic_value()
        if (tof_value > tof_threshold):
            drive_stop()
        if(us_value < us_threshold):
            drive_right()
        if CURRENT_STATE == -1:
            dbg_print("INFO: Initialized")
        
        
        print (get_tof_value())
        start = time.time()
        img = capture_image()
        end = time.time()
        dbg_print("INFO: Time taken for image capture: {0} ms".format((end-start)*1000))
        start = time.time()
        my_classifier(img)
        end = time.time()
        dbg_print("INFO: Time taken for classification: {0} ms".format((end-start)*1000))
    '''
